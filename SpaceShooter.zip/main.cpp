#include "menu.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
using namespace sf;

int main()
{
    Menu m;
    m.display_menu();
    return 0;
}
